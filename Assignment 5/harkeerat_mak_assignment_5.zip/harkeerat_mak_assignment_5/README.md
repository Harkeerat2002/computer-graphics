# Summery:
Group work: Harkeerat Singh Sawhney & Mak Fazlic

# Sources used to find functions/methodologies to calculate the Local Normal:
- https://www.ctralie.com/PrincetonUGRAD/Projects/COS426/Assignment3/part1.html
- https://lousodrome.net/blog/light/2017/01/03/intersection-of-a-ray-and-a-cone/
- https://www.cl.cam.ac.uk/teaching/1999/AGraphHCI/SMAG/node2.html#SECTION00023300000000000000
- https://www.shadertoy.com/view/MtcXWr
- https://stackoverflow.com/questions/13792861/surface-normal-to-a-cone
- https://www.geometrictools.com/Documentation/IntersectionLineCone.pdf
- https://cloud.githubusercontent.com/assets/5027957/16549727/3ac0201a-41f6-11e6-9cb8-2d3118725ed0.png
- https://mlchai.com/files/qin2014cone.pdf
- https://github.com/iceman201/RayTracing/blob/master/Ray%20tracing/Cone.cpp