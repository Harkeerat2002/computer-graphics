//
//  Textures.h
//  Raytracer
//
//  Created by Piotr Didyk on 19.08.21.
//

#ifndef Textures_h
#define Textures_h


#include "glm/glm.hpp"

glm::vec3 checkerboardTexture(glm::vec2 uv){

    /*
     
     
        Exercise 2 (3 points)
     
     
    */
    return glm::vec3(0.0);
}
glm::vec3 rainbowTexture(glm::vec2 uv){
    /*
     
     
        Exercise 2 (5 points)
     
     
    */
    return glm::vec3(0.0);
}

#endif /* Textures_h */
