# Group Work:
Harkeerat Singh Sawhney & Mak Fazlic

# Refferences Used:
- https://stackoverflow.com/questions/25942554/raytracing-shadows